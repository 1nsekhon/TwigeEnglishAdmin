package com.example.twige

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
